from maya import cmds

if not cmds.about(batch=True):
    cmds.evalDeferred("cmds.loadPlugin('MayaScanner.py', quiet=True)")
