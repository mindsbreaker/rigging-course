def as_comma_separated_list(l):
    return ",".join((str(i) for i in l))
